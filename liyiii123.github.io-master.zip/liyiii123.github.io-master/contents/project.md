[![GitHub](https://img.shields.io/badge/GitHub-%23121011?style=for-the-badge&logo=github&logoColor=white)](https://github.com/JerryYin777)
[![GitHub followers](https://img.shields.io/github/followers/JerryYin777?style=for-the-badge&logo=github&label=Followers)](https://github.com/JerryYin777)

<div style="display: flex; flex-wrap: wrap; justify-content: space-around;">
<!--     <a href="https://github.com/OpenBMB/MiniCPM"><img src="https://github-readme-stats.vercel.app/api/pin/?username=OpenBMB&amp;repo=MiniCPM" alt="Readme Card" /></a> -->
    <a href="https://github.com/OpenBMB/BMTrain"><img src="https://github-readme-stats.vercel.app/api/pin/?username=OpenBMB&amp;repo=BMTrain" alt="Readme Card" /></a>
    <a href="https://github.com/CGCL-codes/naturalcc"><img src="https://github-readme-stats.vercel.app/api/pin/?username=CGCL-codes&amp;repo=naturalcc" alt="Readme Card"  /></a>
    <a href="https://github.com/JerryYin777/FPGA_Competition-RISC-V_Processor-in-PGL22G"><img src="https://github-readme-stats.vercel.app/api/pin/?username=JerryYin777&amp;repo=FPGA_Competition-RISC-V_Processor-in-PGL22G" alt="Readme Card"  /></a>
    <a href="https://github.com/bklieger-groq/g1"><img src="https://github-readme-stats.vercel.app/api/pin/?username=bklieger-groq&amp;repo=g1" alt="Readme Card"  /></a>
    <a href="https://github.com/JerryYin777/PaperHelper"><img src="https://github-readme-stats.vercel.app/api/pin/?username=JerryYin777&amp;repo=PaperHelper" alt="Readme Card"  /></a>
    <a href="https://github.com/JerryYin777/Cross-Layer-Attention"><img src="https://github-readme-stats.vercel.app/api/pin/?username=JerryYin777&amp;repo=Cross-Layer-Attention" alt="Readme Card"  /></a>
    <a href="https://github.com/JerryYin777/ASC22-Yuan"><img src="https://github-readme-stats.vercel.app/api/pin/?username=NCUSCC&amp;repo=ASC22-Yuan" alt="Readme Card"  /></a>
    <a href="https://github.com/JerryYin777/NanoGPT-Pytorch2.0-Implementation"><img src="https://github-readme-stats.vercel.app/api/pin/?username=JerryYin777&amp;repo=NanoGPT-Pytorch2.0-Implementation" alt="Readme Card"  /></a>
    <a href="https://github.com/JerryYin777/Cr_Research_Toolchain"><img src="https://github-readme-stats.vercel.app/api/pin/?username=JerryYin777&amp;repo=Cr_Research_Toolchain" alt="Readme Card"  /></a>

    
</div>

