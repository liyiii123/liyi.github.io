
- **Dean's List (All Semester)** at University of Minnesota Twin Cities.

- Special Corporate Scholarships, 2023. **(1/30)**

- School Special Academic Scholarship, 2023.**(1%)**

- First-Class Academic Scholarship, 2022.**(8%)**